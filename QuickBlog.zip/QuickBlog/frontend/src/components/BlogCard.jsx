import React from 'react'
import { useNavigate } from 'react-router-dom'

const stripHtml = (html) => html.replace(/<[^>]+>/g, '')

const BlogCard = ({ blog }) => {
  if (!blog || !blog._id || !blog.title || !blog.image) return null

  const navigate = useNavigate()
  const plainText = stripHtml(blog.description)
  const preview = plainText.slice(0, 100) + '...'
  const { title, category, image, _id } = blog

  return (
    <div
      onClick={() => navigate(`/blog/${_id}`)}
      className='w-full rounded-lg overflow-hidden shadow hover:scale-105 hover:shadow-primary/25 duration-300 cursor-pointer'
    >
      <img src={image} alt={title} className='aspect-video w-full object-cover' />
      <span className='ml-5 mt-4 px-3 py-1 inline-block bg-primary/20 rounded-full text-primary text-xs'>
        {category}
      </span>
      <div className='p-5'>
        <h5 className='mb-2 font-medium text-gray-900'>{title}</h5>
        <p className='mb-3 text-xs text-gray-600'>{preview}</p>
      </div>
    </div>
  )
}

export default BlogCard
