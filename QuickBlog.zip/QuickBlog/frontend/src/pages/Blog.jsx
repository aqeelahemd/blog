import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { assets, blog_data, comments_data } from '../assets/assets'
import Navbar from '../components/Navbar'
import Moment from 'moment'

const Blog = () => {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [comments, setComments] = useState([]);

  useEffect(() => {
    // Find the blog post by id
    const foundData = blog_data.find(item => item._id === id);
    setData(foundData);

    // For now just load all comments (you might want to filter by blog id)
    setComments(comments_data.filter(comment => comment.blogId === id)); 
    // <-- Assuming comments_data has blogId field
  }, [id]);  // refetch if id changes

  if (!data) return <div>Loading...</div>;

  return (
    <div className='relative'>
      <img
        src={assets.gradientBackground}
        alt='background gradient'
        className='absolute -top-50 -z-[1] opacity-50'
      />
      <Navbar />
      <div className='text-center mt-20 text-gray-600'>
        <p className='text-primary py-4 font-medium'>
          Published on {Moment(data?.createdAt).format('MMMM Do YYYY')}
        </p>
        <h1 className='text-2xl sm:text-5xl font-semibold max-w-2xl mx-auto text-gray-800'>
          {data.title}
        </h1>
        <h2 className='my-5 max-w-lg truncate mx-auto'>{data.subTitle}</h2>
        <p className='inline-block py-1 px-4 rounded-full mb-6 border text-sm border-primary/35 bg-primary/5 font-medium text-primary'>
          Michael Brown
        </p>

        <div className='mx-5 max-w-5xl md:mx-auto my-10 mt-6'>
          <img src={data.image} alt={data.title} className='rounded-3xl mb-5' />
          <div
            className='rich-text max-w-3xl mx-auto'
            dangerouslySetInnerHTML={{ __html: data.description }}
          />
          
          {/* Comments Section */}
          <div className='mt-14 mb-10 max-w-3xl mx-auto text-left'>
            <p className='font-semibold mb-4'>Comments ({comments.length})</p>
            {comments.length === 0 && <p>No comments yet. Be the first to comment!</p>}
            {comments.map(comment => (
              <div
                key={comment._id}
                className='mb-6 border-b border-gray-300 pb-4'
              >
                <p className='font-semibold'>{comment.author}</p>
                <p className='text-sm text-gray-500'>
                  {Moment(comment.createdAt).fromNow()}
                </p>
                <p className='mt-2'>{comment.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;
