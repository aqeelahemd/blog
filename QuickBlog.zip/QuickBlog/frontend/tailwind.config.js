// tailwind.config.js
module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}', // adjust based on your project
  ],
  theme: {
    extend: {
      colors: {
        primary: '#5044E5', // this creates bg-primary, text-primary, etc.
      },
    },
  },
  plugins: [],
}
